package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class function01 {
private static function01 mostCurrent = new function01();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.httputils2service _httputils2service = null;
public b4a.example.xuiviewsutils _xuiviewsutils = null;
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public static String  _progresshide(anywheresoftware.b4a.BA _ba,b4a.example.b4xloadingindicator _obj) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Sub ProgressHide(obj As B4XLoadingIndicator)";
 //BA.debugLineNum = 71;BA.debugLine="ProgressDialogHide";
anywheresoftware.b4a.keywords.Common.ProgressDialogHide();
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return "";
}
public static String  _progressshow(anywheresoftware.b4a.BA _ba,b4a.example.b4xloadingindicator _obj,String _text) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Sub ProgressShow(obj As B4XLoadingIndicator,text A";
 //BA.debugLineNum = 53;BA.debugLine="Log(\"ProgressShow= \"&text)";
anywheresoftware.b4a.keywords.Common.LogImpl("450003970","ProgressShow= "+_text,0);
 //BA.debugLineNum = 56;BA.debugLine="ProgressDialogShow(text)";
anywheresoftware.b4a.keywords.Common.ProgressDialogShow(_ba,BA.ObjectToCharSequence(_text));
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public static String  _showcustomtoast(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.ActivityWrapper _act,Object _txt,boolean _longduration,int _backgroundcolor,int _txtcolor) throws Exception{
b4a.example.bctoast _toast = null;
int _duration = 0;
 //BA.debugLineNum = 37;BA.debugLine="Sub ShowCustomToast(act As Activity, txt As Object";
 //BA.debugLineNum = 38;BA.debugLine="Private toast As BCToast";
_toast = new b4a.example.bctoast();
 //BA.debugLineNum = 39;BA.debugLine="toast.Initialize(act)";
_toast._initialize /*String*/ (_ba,(anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(_act.getObject())));
 //BA.debugLineNum = 41;BA.debugLine="Dim duration As Int";
_duration = 0;
 //BA.debugLineNum = 42;BA.debugLine="If LongDuration Then duration = 4000 Else duratio";
if (_longduration) { 
_duration = (int) (4000);}
else {
_duration = (int) (2000);};
 //BA.debugLineNum = 43;BA.debugLine="toast.DurationMs = duration";
_toast._durationms /*int*/  = _duration;
 //BA.debugLineNum = 45;BA.debugLine="toast.DefaultTextColor = TxtColor";
_toast._defaulttextcolor /*int*/  = _txtcolor;
 //BA.debugLineNum = 46;BA.debugLine="toast.pnl.Color = BackgroundColor";
_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setColor(_backgroundcolor);
 //BA.debugLineNum = 48;BA.debugLine="toast.Show($\"[TextSize=15][Alignment=Center]${txt";
_toast._show /*void*/ (("[TextSize=15][Alignment=Center]"+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",_txt)+"[/Alignment][/TextSize]"));
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
public static String  _showtoast(anywheresoftware.b4a.BA _ba,b4a.example.bctoast _toast,anywheresoftware.b4a.objects.B4XViewWrapper _root1,String _message) throws Exception{
int _backgroundcolor = 0;
int _txtcolor = 0;
 //BA.debugLineNum = 12;BA.debugLine="Sub ShowToast(toast As BCToast,Root1 As B4XView, M";
 //BA.debugLineNum = 13;BA.debugLine="Dim BackgroundColor As Int, TxtColor As Int";
_backgroundcolor = 0;
_txtcolor = 0;
 //BA.debugLineNum = 15;BA.debugLine="BackgroundColor = xui.Color_Yellow";
_backgroundcolor = _xui.Color_Yellow;
 //BA.debugLineNum = 16;BA.debugLine="TxtColor = xui.Color_Red";
_txtcolor = _xui.Color_Red;
 //BA.debugLineNum = 18;BA.debugLine="toast.pnl.RemoveViewFromParent";
_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .RemoveViewFromParent();
 //BA.debugLineNum = 19;BA.debugLine="Root1.AddView(toast.pnl, 0, 0, 0, 0)";
_root1.AddView((android.view.View)(_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getObject()),(int) (0),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 21;BA.debugLine="toast.DefaultTextColor = TxtColor";
_toast._defaulttextcolor /*int*/  = _txtcolor;
 //BA.debugLineNum = 22;BA.debugLine="toast.pnl.Color = BackgroundColor";
_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setColor(_backgroundcolor);
 //BA.debugLineNum = 23;BA.debugLine="toast.DurationMs = 1500";
_toast._durationms /*int*/  = (int) (1500);
 //BA.debugLineNum = 25;BA.debugLine="toast.Show($\" ${Message} \"$)";
_toast._show /*void*/ ((" "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_message))+" "));
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
}
