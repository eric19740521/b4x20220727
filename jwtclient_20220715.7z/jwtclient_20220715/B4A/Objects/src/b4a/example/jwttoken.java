package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class jwttoken extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.jwttoken");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.jwttoken.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _header = "";
public String _payload = "";
public String _signature = "";
public String _base64urlheader = "";
public String _base64urlpayload = "";
public String _hmacsha256signature = "";
public boolean _isshowlog = false;
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.function01 _function01 = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.httputils2service _httputils2service = null;
public b4a.example.xuiviewsutils _xuiviewsutils = null;
public String  _base64decode(String _s) throws Exception{
String _base64chars = "";
String _p = "";
String _r = "";
anywheresoftware.b4j.object.JavaObject _ob = null;
int _c = 0;
int _n = 0;
 //BA.debugLineNum = 169;BA.debugLine="Public Sub Base64Decode(S As String) As String";
 //BA.debugLineNum = 170;BA.debugLine="Dim base64chars As String = \"ABCDEFGHIJKLMNOPQRST";
_base64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 //BA.debugLineNum = 171;BA.debugLine="Dim P,R = \"\" As String";
_p = "";
_r = "";
 //BA.debugLineNum = 174;BA.debugLine="Dim Ob As JavaObject = S 'ignore";
_ob = new anywheresoftware.b4j.object.JavaObject();
_ob = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_s));
 //BA.debugLineNum = 175;BA.debugLine="S=Ob.RunMethod(\"replaceAll\",Array As Object(\"[^AB";
_s = BA.ObjectToString(_ob.RunMethod("replaceAll",new Object[]{(Object)("[^ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=]"),(Object)("")}));
 //BA.debugLineNum = 180;BA.debugLine="If S.CharAt(S.Length-1)=\"=\" Then";
if (_s.charAt((int) (_s.length()-1))==BA.ObjectToChar("=")) { 
 //BA.debugLineNum = 181;BA.debugLine="If S.CharAt(S.Length-2)=\"=\" Then";
if (_s.charAt((int) (_s.length()-2))==BA.ObjectToChar("=")) { 
 //BA.debugLineNum = 182;BA.debugLine="p=\"AA\"";
_p = "AA";
 }else {
 //BA.debugLineNum = 184;BA.debugLine="P=\"A\"";
_p = "A";
 };
 }else {
 //BA.debugLineNum = 187;BA.debugLine="P=\"\"";
_p = "";
 };
 //BA.debugLineNum = 189;BA.debugLine="S=S.SubString2(0,S.Length-P.Length) & P";
_s = _s.substring((int) (0),(int) (_s.length()-_p.length()))+_p;
 //BA.debugLineNum = 191;BA.debugLine="For C = 0 To S.Length-1 Step 4";
{
final int step15 = 4;
final int limit15 = (int) (_s.length()-1);
_c = (int) (0) ;
for (;_c <= limit15 ;_c = _c + step15 ) {
 //BA.debugLineNum = 192;BA.debugLine="Try";
try { //BA.debugLineNum = 193;BA.debugLine="Dim n As Int = Bit.ShiftLeft(base64chars.IndexO";
_n = (int) (__c.Bit.ShiftLeft(_base64chars.indexOf(BA.ObjectToString(_s.charAt(_c))),(int) (18))+__c.Bit.ShiftLeft(_base64chars.indexOf(BA.ObjectToString(_s.charAt((int) (_c+1)))),(int) (12))+__c.Bit.ShiftLeft(_base64chars.indexOf(BA.ObjectToString(_s.charAt((int) (_c+2)))),(int) (6))+_base64chars.indexOf(BA.ObjectToString(_s.charAt((int) (_c+3)))));
 //BA.debugLineNum = 194;BA.debugLine="r = r & Chr(Bit.And(Bit.ShiftRight(n,16),0xFF))";
_r = _r+BA.ObjectToString(__c.Chr(__c.Bit.And(__c.Bit.ShiftRight(_n,(int) (16)),((int)0xff))))+BA.ObjectToString(__c.Chr(__c.Bit.And(__c.Bit.ShiftRight(_n,(int) (8)),((int)0xff))))+BA.ObjectToString(__c.Chr(__c.Bit.And(_n,((int)0xff))));
 } 
       catch (Exception e20) {
			ba.setLastException(e20); //BA.debugLineNum = 196;BA.debugLine="Log(\"Position: \" & C)";
__c.LogImpl("42097179","Position: "+BA.NumberToString(_c),0);
 };
 }
};
 //BA.debugLineNum = 200;BA.debugLine="Return R.SubString2(0, R.Length - P.Length)";
if (true) return _r.substring((int) (0),(int) (_r.length()-_p.length()));
 //BA.debugLineNum = 201;BA.debugLine="End Sub";
return "";
}
public String  _base64encode(String _s) throws Exception{
int _c = 0;
String _base64chars = "";
String _p = "";
String _r = "";
int _n = 0;
int _n1 = 0;
int _n2 = 0;
int _n3 = 0;
int _n4 = 0;
 //BA.debugLineNum = 142;BA.debugLine="Public Sub Base64Encode(S As String) As String";
 //BA.debugLineNum = 143;BA.debugLine="Dim c As Int = S.Length Mod 3";
_c = (int) (_s.length()%3);
 //BA.debugLineNum = 144;BA.debugLine="Dim base64chars As String = \"ABCDEFGHIJKLMNOPQRST";
_base64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 //BA.debugLineNum = 145;BA.debugLine="Dim P = \"\",R = \"\" As String";
_p = "";
_r = "";
 //BA.debugLineNum = 148;BA.debugLine="If c>0 Then";
if (_c>0) { 
 //BA.debugLineNum = 149;BA.debugLine="Do While c<3";
while (_c<3) {
 //BA.debugLineNum = 150;BA.debugLine="P = P & \"=\"";
_p = _p+"=";
 //BA.debugLineNum = 151;BA.debugLine="S = S & \"0\"";
_s = _s+"0";
 //BA.debugLineNum = 152;BA.debugLine="c=c+1";
_c = (int) (_c+1);
 }
;
 };
 //BA.debugLineNum = 156;BA.debugLine="For c = 0 To S.Length-1 Step 3";
{
final int step11 = 3;
final int limit11 = (int) (_s.length()-1);
_c = (int) (0) ;
for (;_c <= limit11 ;_c = _c + step11 ) {
 //BA.debugLineNum = 157;BA.debugLine="If (c > 0 And (c / 3 * 4) Mod 76 = 0) Then R=R &";
if ((_c>0 && (_c/(double)3*4)%76==0)) { 
_r = _r+BA.ObjectToString(__c.Chr((int) (10)))+BA.ObjectToString(__c.Chr((int) (13)));};
 //BA.debugLineNum = 158;BA.debugLine="Dim n As Int = Bit.ShiftLeft(Asc(S.CharAt(c)),16";
_n = (int) (__c.Bit.ShiftLeft(__c.Asc(_s.charAt(_c)),(int) (16))+__c.Bit.ShiftLeft(__c.Asc(_s.charAt((int) (_c+1))),(int) (8))+__c.Asc(_s.charAt((int) (_c+2))));
 //BA.debugLineNum = 159;BA.debugLine="Dim n1 As Int = Bit.And(Bit.ShiftRight(n,18),63)";
_n1 = __c.Bit.And(__c.Bit.ShiftRight(_n,(int) (18)),(int) (63));
 //BA.debugLineNum = 160;BA.debugLine="Dim n2 As Int = Bit.And(Bit.ShiftRight(n,12),63)";
_n2 = __c.Bit.And(__c.Bit.ShiftRight(_n,(int) (12)),(int) (63));
 //BA.debugLineNum = 161;BA.debugLine="Dim n3 As Int = Bit.And(Bit.ShiftRight(n,6),63)";
_n3 = __c.Bit.And(__c.Bit.ShiftRight(_n,(int) (6)),(int) (63));
 //BA.debugLineNum = 162;BA.debugLine="Dim n4 As Int = Bit.And(n,63)";
_n4 = __c.Bit.And(_n,(int) (63));
 //BA.debugLineNum = 164;BA.debugLine="R = R & base64chars.CharAt(n1) & base64chars.Cha";
_r = _r+BA.ObjectToString(_base64chars.charAt(_n1))+BA.ObjectToString(_base64chars.charAt(_n2))+BA.ObjectToString(_base64chars.charAt(_n3))+BA.ObjectToString(_base64chars.charAt(_n4));
 }
};
 //BA.debugLineNum = 166;BA.debugLine="Return r.substring2(0, r.length - p.length) & p";
if (true) return _r.substring((int) (0),(int) (_r.length()-_p.length()))+_p;
 //BA.debugLineNum = 167;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 5;BA.debugLine="Private Header As String = \"\"";
_header = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Payload As String = \"\"";
_payload = "";
 //BA.debugLineNum = 7;BA.debugLine="Private Signature As String = \"\"";
_signature = "";
 //BA.debugLineNum = 9;BA.debugLine="Private Base64UrlHeader As String = \"\"";
_base64urlheader = "";
 //BA.debugLineNum = 10;BA.debugLine="Private Base64UrlPayload As String = \"\"";
_base64urlpayload = "";
 //BA.debugLineNum = 11;BA.debugLine="Private HMACSHA256Signature As String = \"\"";
_hmacsha256signature = "";
 //BA.debugLineNum = 13;BA.debugLine="Public isShowLog As Boolean = False";
_isshowlog = __c.False;
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public String  _createhash(String _key,String _algorithm,String _data,String _charset) throws Exception{
anywheresoftware.b4a.agraham.encryption.CipherWrapper.MacWrapper _m = null;
anywheresoftware.b4a.agraham.encryption.CipherWrapper.KeyGeneratorWrapper _k = null;
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
byte[] _b = null;
 //BA.debugLineNum = 222;BA.debugLine="Sub CreateHash(key As String,algorithm As String,d";
 //BA.debugLineNum = 224;BA.debugLine="Dim m As Mac";
_m = new anywheresoftware.b4a.agraham.encryption.CipherWrapper.MacWrapper();
 //BA.debugLineNum = 225;BA.debugLine="Dim k As KeyGenerator";
_k = new anywheresoftware.b4a.agraham.encryption.CipherWrapper.KeyGeneratorWrapper();
 //BA.debugLineNum = 226;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 227;BA.debugLine="k.Initialize(algorithm)";
_k.Initialize(_algorithm);
 //BA.debugLineNum = 228;BA.debugLine="k.KeyFromBytes(key.GetBytes(charset))";
_k.KeyFromBytes(_key.getBytes(_charset));
 //BA.debugLineNum = 229;BA.debugLine="m.Initialise(algorithm, k.Key)";
_m.Initialise(_algorithm,(java.security.Key)(_k.getKey()));
 //BA.debugLineNum = 230;BA.debugLine="m.Update(data.GetBytes(charset))";
_m.Update(_data.getBytes(_charset));
 //BA.debugLineNum = 231;BA.debugLine="Dim b() As Byte";
_b = new byte[(int) (0)];
;
 //BA.debugLineNum = 232;BA.debugLine="b = m.Sign";
_b = _m.Sign();
 //BA.debugLineNum = 233;BA.debugLine="Return bc.HexFromBytes(b)";
if (true) return _bc.HexFromBytes(_b);
 //BA.debugLineNum = 235;BA.debugLine="End Sub";
return "";
}
public String  _getbase64urlheader() throws Exception{
 //BA.debugLineNum = 250;BA.debugLine="Public Sub getBase64UrlHeader As String";
 //BA.debugLineNum = 252;BA.debugLine="Return Base64UrlHeader";
if (true) return _base64urlheader;
 //BA.debugLineNum = 253;BA.debugLine="End Sub";
return "";
}
public String  _getbase64urlpayload() throws Exception{
 //BA.debugLineNum = 254;BA.debugLine="public Sub getBase64UrlPayload As String";
 //BA.debugLineNum = 256;BA.debugLine="Return Base64UrlPayload";
if (true) return _base64urlpayload;
 //BA.debugLineNum = 257;BA.debugLine="End Sub";
return "";
}
public String  _gethashbase64(String _inp) throws Exception{
anywheresoftware.b4a.agraham.byteconverter.ByteConverter _bc = null;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _res = "";
 //BA.debugLineNum = 203;BA.debugLine="Sub getHashBase64(inp As String) As String";
 //BA.debugLineNum = 205;BA.debugLine="Dim bc As ByteConverter";
_bc = new anywheresoftware.b4a.agraham.byteconverter.ByteConverter();
 //BA.debugLineNum = 206;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 208;BA.debugLine="Dim res As String =  su.EncodeBase64(bc.HexToByte";
_res = _su.EncodeBase64(_bc.HexToBytes(_inp));
 //BA.debugLineNum = 210;BA.debugLine="res=res.Replace(\"+\",\"-\")";
_res = _res.replace("+","-");
 //BA.debugLineNum = 211;BA.debugLine="res=res.Replace(\"/\",\"_\")";
_res = _res.replace("/","_");
 //BA.debugLineNum = 214;BA.debugLine="If res.EndsWith(\"=\") Then ' remove padding";
if (_res.endsWith("=")) { 
 //BA.debugLineNum = 215;BA.debugLine="res = res.Replace(\"=\",\"\")";
_res = _res.replace("=","");
 };
 //BA.debugLineNum = 218;BA.debugLine="Return res";
if (true) return _res;
 //BA.debugLineNum = 220;BA.debugLine="End Sub";
return "";
}
public String  _getheader() throws Exception{
 //BA.debugLineNum = 239;BA.debugLine="Public Sub getHeader As String";
 //BA.debugLineNum = 241;BA.debugLine="Return Header";
if (true) return _header;
 //BA.debugLineNum = 242;BA.debugLine="End Sub";
return "";
}
public String  _gethmacsha256signature() throws Exception{
 //BA.debugLineNum = 258;BA.debugLine="public Sub getHMACSHA256Signature As String";
 //BA.debugLineNum = 260;BA.debugLine="Return HMACSHA256Signature";
if (true) return _hmacsha256signature;
 //BA.debugLineNum = 261;BA.debugLine="End Sub";
return "";
}
public String  _getpayload() throws Exception{
 //BA.debugLineNum = 243;BA.debugLine="public Sub getPayload As String";
 //BA.debugLineNum = 245;BA.debugLine="Return Payload";
if (true) return _payload;
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return "";
}
public String  _gettoken(String _payloadstring,String _key) throws Exception{
String _token = "";
 //BA.debugLineNum = 23;BA.debugLine="Public Sub getToken(payloadString As String,key As";
 //BA.debugLineNum = 24;BA.debugLine="ShowLog(\"JwtToken.getToken==>\")";
_showlog("JwtToken.getToken==>");
 //BA.debugLineNum = 26;BA.debugLine="Dim token As String = \"\"";
_token = "";
 //BA.debugLineNum = 29;BA.debugLine="Header = \"\"";
_header = "";
 //BA.debugLineNum = 30;BA.debugLine="Payload = \"\"";
_payload = "";
 //BA.debugLineNum = 31;BA.debugLine="Signature = \"\"";
_signature = "";
 //BA.debugLineNum = 32;BA.debugLine="Base64UrlHeader = \"\"";
_base64urlheader = "";
 //BA.debugLineNum = 33;BA.debugLine="Base64UrlPayload = \"\"";
_base64urlpayload = "";
 //BA.debugLineNum = 34;BA.debugLine="HMACSHA256Signature = \"\"";
_hmacsha256signature = "";
 //BA.debugLineNum = 37;BA.debugLine="Header = $\"{\"alg\":\"HS256\",\"typ\":\"JWT\"}\"$";
_header = ("{\"alg\":\"HS256\",\"typ\":\"JWT\"}");
 //BA.debugLineNum = 38;BA.debugLine="Base64UrlHeader=Base64Encode(Header)";
_base64urlheader = _base64encode(_header);
 //BA.debugLineNum = 39;BA.debugLine="ShowLog(\"base64Url Header= \"&Base64UrlHeader)";
_showlog("base64Url Header= "+_base64urlheader);
 //BA.debugLineNum = 42;BA.debugLine="Payload = payloadString";
_payload = _payloadstring;
 //BA.debugLineNum = 43;BA.debugLine="Base64UrlPayload=Base64Encode(Payload)";
_base64urlpayload = _base64encode(_payload);
 //BA.debugLineNum = 44;BA.debugLine="ShowLog(\"base64Url Payload= \"&Base64UrlPayload)";
_showlog("base64Url Payload= "+_base64urlpayload);
 //BA.debugLineNum = 47;BA.debugLine="Dim Signature As String=Base64UrlHeader&\".\"&Base6";
_signature = _base64urlheader+"."+_base64urlpayload;
 //BA.debugLineNum = 48;BA.debugLine="ShowLog(\"signature= \" &Signature)";
_showlog("signature= "+_signature);
 //BA.debugLineNum = 50;BA.debugLine="HMACSHA256Signature = getHashBase64(CreateHash(ke";
_hmacsha256signature = _gethashbase64(_createhash(_key,"HMACSHA256",_signature,"ASCII"));
 //BA.debugLineNum = 52;BA.debugLine="ShowLog(\"HMACSHA256 signature= \" &HMACSHA256Signa";
_showlog("HMACSHA256 signature= "+_hmacsha256signature);
 //BA.debugLineNum = 55;BA.debugLine="token = Base64UrlHeader &\".\"& Base64UrlPayload &\"";
_token = _base64urlheader+"."+_base64urlpayload+"."+_hmacsha256signature;
 //BA.debugLineNum = 57;BA.debugLine="ShowLog(\"jwt token= \" & token  )";
_showlog("jwt token= "+_token);
 //BA.debugLineNum = 59;BA.debugLine="Return token";
if (true) return _token;
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 19;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public String  _showlog(String _s) throws Exception{
 //BA.debugLineNum = 125;BA.debugLine="Sub ShowLog(s As String)";
 //BA.debugLineNum = 127;BA.debugLine="If isShowLog Then";
if (_isshowlog) { 
 //BA.debugLineNum = 128;BA.debugLine="Log(s)";
__c.LogImpl("41966083",_s,0);
 };
 //BA.debugLineNum = 133;BA.debugLine="End Sub";
return "";
}
public boolean  _verifytoken(String _token,String _mykey) throws Exception{
String _v1token = "";
String _s5 = "";
 //BA.debugLineNum = 62;BA.debugLine="public Sub verifyToken(token As String,mykey As St";
 //BA.debugLineNum = 63;BA.debugLine="ShowLog(\"JwtToken.verifyToken==>\")";
_showlog("JwtToken.verifyToken==>");
 //BA.debugLineNum = 64;BA.debugLine="ShowLog(\"verifyToken= \"&token)";
_showlog("verifyToken= "+_token);
 //BA.debugLineNum = 66;BA.debugLine="Dim v1token As String = \"\"";
_v1token = "";
 //BA.debugLineNum = 68;BA.debugLine="Header = \"\"";
_header = "";
 //BA.debugLineNum = 69;BA.debugLine="Payload = \"\"";
_payload = "";
 //BA.debugLineNum = 70;BA.debugLine="Signature = \"\"";
_signature = "";
 //BA.debugLineNum = 71;BA.debugLine="Base64UrlHeader = \"\"";
_base64urlheader = "";
 //BA.debugLineNum = 72;BA.debugLine="Base64UrlPayload = \"\"";
_base64urlpayload = "";
 //BA.debugLineNum = 73;BA.debugLine="HMACSHA256Signature = \"\"";
_hmacsha256signature = "";
 //BA.debugLineNum = 75;BA.debugLine="Dim s5 As String";
_s5 = "";
 //BA.debugLineNum = 78;BA.debugLine="Base64UrlHeader = token.SubString2(0, token.Index";
_base64urlheader = _token.substring((int) (0),_token.indexOf("."));
 //BA.debugLineNum = 79;BA.debugLine="s5 = token.SubString(token.IndexOf(\".\")+1)";
_s5 = _token.substring((int) (_token.indexOf(".")+1));
 //BA.debugLineNum = 80;BA.debugLine="Base64UrlPayload = s5.SubString2(0, s5.IndexOf(\".";
_base64urlpayload = _s5.substring((int) (0),_s5.indexOf("."));
 //BA.debugLineNum = 81;BA.debugLine="HMACSHA256Signature = s5.SubString(s5.IndexOf(\".\"";
_hmacsha256signature = _s5.substring((int) (_s5.indexOf(".")+1));
 //BA.debugLineNum = 83;BA.debugLine="ShowLog(\"base64Url Header=> \"&Base64UrlHeader)";
_showlog("base64Url Header=> "+_base64urlheader);
 //BA.debugLineNum = 84;BA.debugLine="ShowLog(\"base64Url Payload=> \"&Base64UrlPayload)";
_showlog("base64Url Payload=> "+_base64urlpayload);
 //BA.debugLineNum = 85;BA.debugLine="ShowLog(\"HMACSHA256 signature=> \"&HMACSHA256Signa";
_showlog("HMACSHA256 signature=> "+_hmacsha256signature);
 //BA.debugLineNum = 94;BA.debugLine="Header = Base64Decode(Base64UrlHeader)";
_header = _base64decode(_base64urlheader);
 //BA.debugLineNum = 95;BA.debugLine="Payload = Base64Decode(Base64UrlPayload)";
_payload = _base64decode(_base64urlpayload);
 //BA.debugLineNum = 99;BA.debugLine="ShowLog(\"原始內容\")";
_showlog("原始內容");
 //BA.debugLineNum = 100;BA.debugLine="ShowLog(\"Header=> \"&Header)";
_showlog("Header=> "+_header);
 //BA.debugLineNum = 101;BA.debugLine="ShowLog(\"Payload=> \"&Payload)";
_showlog("Payload=> "+_payload);
 //BA.debugLineNum = 104;BA.debugLine="Signature = Base64Encode(Header)&\".\"&Base64Encode";
_signature = _base64encode(_header)+"."+_base64encode(_payload);
 //BA.debugLineNum = 105;BA.debugLine="ShowLog(\"signature==> \" &Signature)";
_showlog("signature==> "+_signature);
 //BA.debugLineNum = 106;BA.debugLine="HMACSHA256Signature = getHashBase64(CreateHash(my";
_hmacsha256signature = _gethashbase64(_createhash(_mykey,"HMACSHA256",_signature,"ASCII"));
 //BA.debugLineNum = 107;BA.debugLine="ShowLog(\"HMACSHA256 signature= \" &HMACSHA256Signa";
_showlog("HMACSHA256 signature= "+_hmacsha256signature);
 //BA.debugLineNum = 109;BA.debugLine="v1token = Signature &\".\"&HMACSHA256Signature";
_v1token = _signature+"."+_hmacsha256signature;
 //BA.debugLineNum = 112;BA.debugLine="If v1token = token Then	'檢驗token是否被修改";
if ((_v1token).equals(_token)) { 
 //BA.debugLineNum = 113;BA.debugLine="Return True";
if (true) return __c.True;
 }else {
 //BA.debugLineNum = 115;BA.debugLine="Return False";
if (true) return __c.False;
 };
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return false;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
