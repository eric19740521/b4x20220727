package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class memberpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.memberpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.memberpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example3.customlistview _clvdata = null;
public b4a.example.preferencesdialog _prefdialog = null;
public b4a.example.ddd _dd = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_no = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_name = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_password = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_memo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbledit = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbldelete = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _label1 = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.function01 _function01 = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.httputils2service _httputils2service = null;
public b4a.example.xuiviewsutils _xuiviewsutils = null;
public void  _adddata() throws Exception{
ResumableSub_AddData rsub = new ResumableSub_AddData(this);
rsub.resume(ba, null);
}
public static class ResumableSub_AddData extends BA.ResumableSub {
public ResumableSub_AddData(b4a.example.memberpage parent) {
this.parent = parent;
}
b4a.example.memberpage parent;
anywheresoftware.b4a.objects.collections.Map _item = null;
int _result = 0;
String[] _parametros = null;
anywheresoftware.b4a.objects.collections.Map _answer = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 189;BA.debugLine="Dim Item As Map = CreateMap()";
_item = new anywheresoftware.b4a.objects.collections.Map();
_item = parent.__c.createMap(new Object[] {});
 //BA.debugLineNum = 190;BA.debugLine="PrefDialog.Title = \"會員資料-新增\"";
parent._prefdialog._settitle /*Object*/ ((Object)("會員資料-新增"));
 //BA.debugLineNum = 191;BA.debugLine="PrefDialog.LoadFromJson(File.ReadString(File.DirA";
parent._prefdialog._loadfromjson /*String*/ (parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"template.json"));
 //BA.debugLineNum = 193;BA.debugLine="Wait For (PrefDialog.ShowDialog(Item, \"OK\", \"CANC";
parent.__c.WaitFor("complete", ba, this, parent._prefdialog._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_item,(Object)("OK"),(Object)("CANCEL")));
this.state = 17;
return;
case 17:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 194;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 195;BA.debugLine="Log(\"遠端新增...\")";
parent.__c.LogImpl("72162696","遠端新增...",0);
 //BA.debugLineNum = 199;BA.debugLine="Try";
if (true) break;

case 4:
//try
this.state = 15;
this.catchState = 14;
this.state = 6;
if (true) break;

case 6:
//C
this.state = 7;
this.catchState = 14;
 //BA.debugLineNum = 200;BA.debugLine="Function01.ProgressShow(Null,\"Connecting to ser";
parent._function01._progressshow /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null),"Connecting to server...");
 //BA.debugLineNum = 201;BA.debugLine="Dim Parametros() As String =  Array As String(I";
_parametros = new String[]{BA.ObjectToString(_item.Get((Object)("mem_no"))),BA.ObjectToString(_item.Get((Object)("mem_name"))),BA.ObjectToString(_item.Get((Object)("mem_password"))),BA.ObjectToString(_item.Get((Object)("mem_memo")))};
 //BA.debugLineNum = 202;BA.debugLine="Wait For(B4XPages.MainPage.jRDC.InsertUpdateRec";
parent.__c.WaitFor("complete", ba, this, parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._jrdc /*b4a.example.jrdc2*/ ._insertupdaterecord /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("member_Insert",_parametros));
this.state = 18;
return;
case 18:
//C
this.state = 7;
_answer = (anywheresoftware.b4a.objects.collections.Map) result[0];
;
 //BA.debugLineNum = 203;BA.debugLine="Function01.ProgressHide(Null)";
parent._function01._progresshide /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null));
 //BA.debugLineNum = 204;BA.debugLine="If Answer.Get(\"Success\") Then";
if (true) break;

case 7:
//if
this.state = 12;
if (BA.ObjectToBoolean(_answer.Get((Object)("Success")))) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 206;BA.debugLine="Log(\"本地新增...\")";
parent.__c.LogImpl("72162707","本地新增...",0);
 //BA.debugLineNum = 207;BA.debugLine="Dim p As B4XView = CreateCard(Item)";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._createcard(_item);
 //BA.debugLineNum = 208;BA.debugLine="clvData.Add(p, Item)";
parent._clvdata._add(_p,(Object)(_item.getObject()));
 //BA.debugLineNum = 209;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,"新增成功!!");
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 211;BA.debugLine="xui.MsgboxAsync(\"Problem connecting: \" & Answe";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence("Problem connecting: "+BA.ObjectToString(_answer.Get((Object)("Error")))),BA.ObjectToCharSequence("Error"));
 if (true) break;

case 12:
//C
this.state = 15;
;
 if (true) break;

case 14:
//C
this.state = 15;
this.catchState = 0;
 //BA.debugLineNum = 216;BA.debugLine="Log(LastException)";
parent.__c.LogImpl("72162717",BA.ObjectToString(parent.__c.LastException(ba)),0);
 if (true) break;
if (true) break;

case 15:
//C
this.state = 16;
this.catchState = 0;
;
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 224;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
anywheresoftware.b4a.objects.CSBuilder _cs = null;
b4a.example.b4xpagesmanager._b4amenuitem _mi = null;
 //BA.debugLineNum = 26;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 29;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 33;BA.debugLine="dd.Initialize";
_dd._initialize /*String*/ (ba);
 //BA.debugLineNum = 34;BA.debugLine="xui.RegisterDesignerClass(dd)";
_xui.RegisterDesignerClass((Object)(_dd));
 //BA.debugLineNum = 40;BA.debugLine="Root.LoadLayout(\"MemberPage\")";
_root.LoadLayout("MemberPage",ba);
 //BA.debugLineNum = 41;BA.debugLine="B4XPages.SetTitle(Me, \"會員資料\")";
_b4xpages._settitle /*String*/ (ba,this,(Object)("會員資料"));
 //BA.debugLineNum = 44;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 45;BA.debugLine="Dim mi As B4AMenuItem";
_mi = new b4a.example.b4xpagesmanager._b4amenuitem();
 //BA.debugLineNum = 46;BA.debugLine="mi = B4XPages.AddMenuItem(Me, cs.Initialize.Typef";
_mi = _b4xpages._addmenuitem /*b4a.example.b4xpagesmanager._b4amenuitem*/ (ba,this,(Object)(_cs.Initialize().Typeface(__c.Typeface.getFONTAWESOME()).Size((int) (22)).Append(BA.ObjectToCharSequence(_b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._pluschar /*String*/ )).PopAll().getObject()));
 //BA.debugLineNum = 47;BA.debugLine="mi.AddToBar = True";
_mi.AddToBar /*boolean*/  = __c.True;
 //BA.debugLineNum = 48;BA.debugLine="mi.Tag = \"Add Event\"";
_mi.Tag /*String*/  = "Add Event";
 //BA.debugLineNum = 49;BA.debugLine="mi = B4XPages.AddMenuItem(Me, cs.Initialize.Typef";
_mi = _b4xpages._addmenuitem /*b4a.example.b4xpagesmanager._b4amenuitem*/ (ba,this,(Object)(_cs.Initialize().Typeface(__c.Typeface.getFONTAWESOME()).Size((int) (22)).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xf0e2)))).PopAll().getObject()));
 //BA.debugLineNum = 50;BA.debugLine="mi.AddToBar = True";
_mi.AddToBar /*boolean*/  = __c.True;
 //BA.debugLineNum = 51;BA.debugLine="mi.Tag = \"Refresh Event\"";
_mi.Tag /*String*/  = "Refresh Event";
 //BA.debugLineNum = 52;BA.debugLine="B4XPages.AddMenuItem(Me,\"mnu2\")";
_b4xpages._addmenuitem /*b4a.example.b4xpagesmanager._b4amenuitem*/ (ba,this,(Object)("mnu2"));
 //BA.debugLineNum = 55;BA.debugLine="PrefDialog.Initialize(Root, \"編輯\", 300dip , 400dip";
_prefdialog._initialize /*String*/ (ba,_root,(Object)("編輯"),__c.DipToCurrent((int) (300)),__c.DipToCurrent((int) (400)));
 //BA.debugLineNum = 59;BA.debugLine="PrefDialog.SetEventsListener(Me, \"PrefDialog\")";
_prefdialog._seteventslistener /*String*/ (this,"PrefDialog");
 //BA.debugLineNum = 63;BA.debugLine="QueryData";
_querydata();
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_menuclick(String _tag) throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Sub B4XPage_MenuClick (Tag As String)";
 //BA.debugLineNum = 76;BA.debugLine="Log(\"B4XPage_MenuClick==>\")";
__c.LogImpl("71966081","B4XPage_MenuClick==>",0);
 //BA.debugLineNum = 77;BA.debugLine="Log(Tag)";
__c.LogImpl("71966082",_tag,0);
 //BA.debugLineNum = 79;BA.debugLine="If Tag = \"Add Event\" Then";
if ((_tag).equals("Add Event")) { 
 //BA.debugLineNum = 80;BA.debugLine="Log(\"Add Event\")";
__c.LogImpl("71966085","Add Event",0);
 //BA.debugLineNum = 82;BA.debugLine="AddData";
_adddata();
 };
 //BA.debugLineNum = 84;BA.debugLine="If Tag = \"Refresh Event\" Then";
if ((_tag).equals("Refresh Event")) { 
 //BA.debugLineNum = 85;BA.debugLine="Log(\"Refresh Event\")";
__c.LogImpl("71966090","Refresh Event",0);
 //BA.debugLineNum = 87;BA.debugLine="QueryData";
_querydata();
 };
 //BA.debugLineNum = 89;BA.debugLine="If Tag = \"mnu2\" Then";
if ((_tag).equals("mnu2")) { 
 //BA.debugLineNum = 90;BA.debugLine="Log(\"mnu2\")";
__c.LogImpl("71966095","mnu2",0);
 //BA.debugLineNum = 93;BA.debugLine="Function01.ShowToast ( B4XPages.MainPage.toast ,";
_function01._showtoast /*String*/ (ba,_b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,_root,"mnu2");
 };
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_resize(int _width,int _height) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Sub B4XPage_Resize (Width As Int, Height As Int)";
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 6;BA.debugLine="Private clvData As CustomListView";
_clvdata = new b4a.example3.customlistview();
 //BA.debugLineNum = 7;BA.debugLine="Public PrefDialog As PreferencesDialog";
_prefdialog = new b4a.example.preferencesdialog();
 //BA.debugLineNum = 8;BA.debugLine="Private dd As DDD";
_dd = new b4a.example.ddd();
 //BA.debugLineNum = 11;BA.debugLine="Private lblMem_No As B4XView";
_lblmem_no = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private lblMem_Name As B4XView";
_lblmem_name = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private lblMem_Password As B4XView";
_lblmem_password = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private lblMem_Memo As B4XView";
_lblmem_memo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private lblEdit As B4XView";
_lbledit = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private lblDelete As B4XView";
_lbldelete = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private Label1 As B4XView";
_label1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _createcard(anywheresoftware.b4a.objects.collections.Map _data) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
int _height = 0;
 //BA.debugLineNum = 100;BA.debugLine="Sub CreateCard (Data As Map) As B4XView";
 //BA.debugLineNum = 101;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 102;BA.debugLine="Dim height As Int = 220dip";
_height = __c.DipToCurrent((int) (220));
 //BA.debugLineNum = 104;BA.debugLine="height = clvData.AsView.Height /3 -2dip";
_height = (int) (_clvdata._asview().getHeight()/(double)3-__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 107;BA.debugLine="If GetDeviceLayoutValues.ApproximateScreenSize <";
if (__c.GetDeviceLayoutValues(ba).getApproximateScreenSize()<4.5) { 
_height = __c.DipToCurrent((int) (310));};
 //BA.debugLineNum = 109;BA.debugLine="Log(\"ApproximateScreenSize= \"&GetDeviceLayoutValu";
__c.LogImpl("72031625","ApproximateScreenSize= "+BA.NumberToString(__c.GetDeviceLayoutValues(ba).getApproximateScreenSize()),0);
 //BA.debugLineNum = 112;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, clvData.AsView.Width";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_clvdata._asview().getWidth(),_height);
 //BA.debugLineNum = 113;BA.debugLine="p.LoadLayout(\"Card\")";
_p.LoadLayout("Card",ba);
 //BA.debugLineNum = 116;BA.debugLine="lblMem_No.Text = Data.Get(\"mem_no\")";
_lblmem_no.setText(BA.ObjectToCharSequence(_data.Get((Object)("mem_no"))));
 //BA.debugLineNum = 117;BA.debugLine="lblMem_Name.Text = Data.Get(\"mem_name\")";
_lblmem_name.setText(BA.ObjectToCharSequence(_data.Get((Object)("mem_name"))));
 //BA.debugLineNum = 118;BA.debugLine="lblMem_Password.Text = Data.Get(\"mem_password\")";
_lblmem_password.setText(BA.ObjectToCharSequence(_data.Get((Object)("mem_password"))));
 //BA.debugLineNum = 119;BA.debugLine="lblMem_Memo.Text = Data.Get(\"mem_memo\")";
_lblmem_memo.setText(BA.ObjectToCharSequence(_data.Get((Object)("mem_memo"))));
 //BA.debugLineNum = 122;BA.debugLine="lblEdit.Tag = Data";
_lbledit.setTag((Object)(_data.getObject()));
 //BA.debugLineNum = 123;BA.debugLine="lblDelete.Tag = Data";
_lbldelete.setTag((Object)(_data.getObject()));
 //BA.debugLineNum = 124;BA.debugLine="Return p";
if (true) return _p;
 //BA.debugLineNum = 125;BA.debugLine="End Sub";
return null;
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 21;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 22;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return null;
}
public void  _lbldelete_click() throws Exception{
ResumableSub_lblDelete_Click rsub = new ResumableSub_lblDelete_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_lblDelete_Click extends BA.ResumableSub {
public ResumableSub_lblDelete_Click(b4a.example.memberpage parent) {
this.parent = parent;
}
b4a.example.memberpage parent;
int _index = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _l = null;
anywheresoftware.b4a.objects.collections.Map _item = null;
Object _sf = null;
int _result = 0;
String[] _parametros = null;
anywheresoftware.b4a.objects.collections.Map _answer = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 293;BA.debugLine="Log(\"lblDelete_Click==>\")";
parent.__c.LogImpl("72293761","lblDelete_Click==>",0);
 //BA.debugLineNum = 295;BA.debugLine="Dim Index As Int = clvData.GetItemFromView(Sender";
_index = parent._clvdata._getitemfromview((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba))));
 //BA.debugLineNum = 297;BA.debugLine="Dim l As B4XView";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 300;BA.debugLine="Dim l As B4XView";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 302;BA.debugLine="l = Sender";
_l = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 303;BA.debugLine="Dim Item As Map";
_item = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 304;BA.debugLine="Item.Initialize";
_item.Initialize();
 //BA.debugLineNum = 305;BA.debugLine="Item = l.Tag";
_item = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_l.getTag()));
 //BA.debugLineNum = 308;BA.debugLine="Dim sf As Object = xui.Msgbox2Async($\"刪除會員: ${Ite";
_sf = parent._xui.Msgbox2Async(ba,BA.ObjectToCharSequence(("刪除會員: "+parent.__c.SmartStringFormatter("",_item.Get((Object)("mem_name")))+"?")),BA.ObjectToCharSequence(""),"Yes","","No",(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper(), (android.graphics.Bitmap)(parent.__c.Null)));
 //BA.debugLineNum = 310;BA.debugLine="Wait For (sf) Msgbox_Result (Result As Int)";
parent.__c.WaitFor("msgbox_result", ba, this, _sf);
this.state = 17;
return;
case 17:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 311;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 312;BA.debugLine="Log(\"遠端刪除...\")";
parent.__c.LogImpl("72293780","遠端刪除...",0);
 //BA.debugLineNum = 314;BA.debugLine="Try";
if (true) break;

case 4:
//try
this.state = 15;
this.catchState = 14;
this.state = 6;
if (true) break;

case 6:
//C
this.state = 7;
this.catchState = 14;
 //BA.debugLineNum = 315;BA.debugLine="Function01.ProgressShow(Null,\"Connecting to ser";
parent._function01._progressshow /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null),"Connecting to server...");
 //BA.debugLineNum = 316;BA.debugLine="Dim Parametros() As String =  Array As String(I";
_parametros = new String[]{BA.ObjectToString(_item.Get((Object)("mem_no")))};
 //BA.debugLineNum = 317;BA.debugLine="Wait For(B4XPages.MainPage.jRDC.InsertUpdateRec";
parent.__c.WaitFor("complete", ba, this, parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._jrdc /*b4a.example.jrdc2*/ ._insertupdaterecord /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("member_Delete",_parametros));
this.state = 18;
return;
case 18:
//C
this.state = 7;
_answer = (anywheresoftware.b4a.objects.collections.Map) result[0];
;
 //BA.debugLineNum = 318;BA.debugLine="Function01.ProgressHide(Null)";
parent._function01._progresshide /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null));
 //BA.debugLineNum = 319;BA.debugLine="If Answer.Get(\"Success\") Then";
if (true) break;

case 7:
//if
this.state = 12;
if (BA.ObjectToBoolean(_answer.Get((Object)("Success")))) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 321;BA.debugLine="Log(\"本地刪除...\")";
parent.__c.LogImpl("72293789","本地刪除...",0);
 //BA.debugLineNum = 322;BA.debugLine="clvData.RemoveAt(Index)";
parent._clvdata._removeat(_index);
 //BA.debugLineNum = 323;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,"刪除成功!!");
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 326;BA.debugLine="xui.MsgboxAsync(\"Problem connecting: \" & Answe";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence("Problem connecting: "+BA.ObjectToString(_answer.Get((Object)("Error")))),BA.ObjectToCharSequence("Error"));
 if (true) break;

case 12:
//C
this.state = 15;
;
 if (true) break;

case 14:
//C
this.state = 15;
this.catchState = 0;
 //BA.debugLineNum = 331;BA.debugLine="Log(LastException)";
parent.__c.LogImpl("72293799",BA.ObjectToString(parent.__c.LastException(ba)),0);
 if (true) break;
if (true) break;

case 15:
//C
this.state = 16;
this.catchState = 0;
;
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 337;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _msgbox_result(int _result) throws Exception{
}
public void  _lbledit_click() throws Exception{
ResumableSub_lblEdit_Click rsub = new ResumableSub_lblEdit_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_lblEdit_Click extends BA.ResumableSub {
public ResumableSub_lblEdit_Click(b4a.example.memberpage parent) {
this.parent = parent;
}
b4a.example.memberpage parent;
int _index = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _l = null;
anywheresoftware.b4a.objects.collections.Map _item = null;
int _result = 0;
String[] _parametros = null;
anywheresoftware.b4a.objects.collections.Map _answer = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 229;BA.debugLine="Log(\"lblEdit_Click==>\")";
parent.__c.LogImpl("72228225","lblEdit_Click==>",0);
 //BA.debugLineNum = 232;BA.debugLine="Dim Index As Int = clvData.GetItemFromView(Sender";
_index = parent._clvdata._getitemfromview((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba))));
 //BA.debugLineNum = 233;BA.debugLine="Dim pnl As B4XView = clvData.GetPanel(Index)";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = parent._clvdata._getpanel(_index);
 //BA.debugLineNum = 234;BA.debugLine="Dim l As B4XView";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 236;BA.debugLine="l = Sender";
_l = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 237;BA.debugLine="Dim Item As Map";
_item = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 238;BA.debugLine="Item.Initialize";
_item.Initialize();
 //BA.debugLineNum = 239;BA.debugLine="Item = l.Tag";
_item = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_l.getTag()));
 //BA.debugLineNum = 240;BA.debugLine="Item.Put(\"mem_oldno\",Item.Get(\"mem_no\"))";
_item.Put((Object)("mem_oldno"),_item.Get((Object)("mem_no")));
 //BA.debugLineNum = 242;BA.debugLine="PrefDialog.Title = \"會員資料-修改\"";
parent._prefdialog._settitle /*Object*/ ((Object)("會員資料-修改"));
 //BA.debugLineNum = 243;BA.debugLine="PrefDialog.LoadFromJson(File.ReadString(File.DirA";
parent._prefdialog._loadfromjson /*String*/ (parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"template.json"));
 //BA.debugLineNum = 245;BA.debugLine="Wait For (PrefDialog.ShowDialog(Item, \"OK\", \"CANC";
parent.__c.WaitFor("complete", ba, this, parent._prefdialog._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_item,(Object)("OK"),(Object)("CANCEL")));
this.state = 27;
return;
case 27:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 246;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 26;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 247;BA.debugLine="Log(\"遠端修改...\")";
parent.__c.LogImpl("72228243","遠端修改...",0);
 //BA.debugLineNum = 249;BA.debugLine="Try";
if (true) break;

case 4:
//try
this.state = 25;
this.catchState = 24;
this.state = 6;
if (true) break;

case 6:
//C
this.state = 7;
this.catchState = 24;
 //BA.debugLineNum = 250;BA.debugLine="Function01.ProgressShow(Null,\"Connecting to ser";
parent._function01._progressshow /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null),"Connecting to server...");
 //BA.debugLineNum = 251;BA.debugLine="Dim Parametros() As String =  Array As String(I";
_parametros = new String[]{BA.ObjectToString(_item.Get((Object)("mem_no"))),BA.ObjectToString(_item.Get((Object)("mem_name"))),BA.ObjectToString(_item.Get((Object)("mem_password"))),BA.ObjectToString(_item.Get((Object)("mem_memo"))),BA.ObjectToString(_item.Get((Object)("mem_oldno")))};
 //BA.debugLineNum = 252;BA.debugLine="Wait For(B4XPages.MainPage.jRDC.InsertUpdateRec";
parent.__c.WaitFor("complete", ba, this, parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._jrdc /*b4a.example.jrdc2*/ ._insertupdaterecord /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("member_Update",_parametros));
this.state = 28;
return;
case 28:
//C
this.state = 7;
_answer = (anywheresoftware.b4a.objects.collections.Map) result[0];
;
 //BA.debugLineNum = 253;BA.debugLine="Function01.ProgressHide(Null)";
parent._function01._progresshide /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null));
 //BA.debugLineNum = 254;BA.debugLine="If Answer.Get(\"Success\") Then";
if (true) break;

case 7:
//if
this.state = 22;
if (BA.ObjectToBoolean(_answer.Get((Object)("Success")))) { 
this.state = 9;
}else {
this.state = 21;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 256;BA.debugLine="Log(\"本地修改...\")";
parent.__c.LogImpl("72228252","本地修改...",0);
 //BA.debugLineNum = 257;BA.debugLine="If pnl.NumberOfViews > 0 Then";
if (true) break;

case 10:
//if
this.state = 19;
if (_pnl.getNumberOfViews()>0) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 260;BA.debugLine="Try";
if (true) break;

case 13:
//try
this.state = 18;
this.catchState = 17;
this.state = 15;
if (true) break;

case 15:
//C
this.state = 18;
this.catchState = 17;
 //BA.debugLineNum = 261;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_no\").Text = It";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_no").setText(BA.ObjectToCharSequence(_item.Get((Object)("mem_no"))));
 //BA.debugLineNum = 262;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_name\").Text =";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_name").setText(BA.ObjectToCharSequence(_item.Get((Object)("mem_name"))));
 //BA.debugLineNum = 263;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_password\").Tex";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_password").setText(BA.ObjectToCharSequence(_item.Get((Object)("mem_password"))));
 //BA.debugLineNum = 264;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_memo\").Text =";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_memo").setText(BA.ObjectToCharSequence(_item.Get((Object)("mem_memo"))));
 //BA.debugLineNum = 266;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toas";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,"修改成功!!");
 if (true) break;

case 17:
//C
this.state = 18;
this.catchState = 24;
 //BA.debugLineNum = 268;BA.debugLine="Log(\"err: \"&LastException)";
parent.__c.LogImpl("72228264","err: "+BA.ObjectToString(parent.__c.LastException(ba)),0);
 //BA.debugLineNum = 269;BA.debugLine="xui.MsgboxAsync(LastException, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(parent.__c.LastException(ba).getObject()),BA.ObjectToCharSequence("Error"));
 if (true) break;
if (true) break;

case 18:
//C
this.state = 19;
this.catchState = 24;
;
 if (true) break;

case 19:
//C
this.state = 22;
;
 if (true) break;

case 21:
//C
this.state = 22;
 //BA.debugLineNum = 275;BA.debugLine="xui.MsgboxAsync(\"Problem connecting: \" & Answe";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence("Problem connecting: "+BA.ObjectToString(_answer.Get((Object)("Error")))),BA.ObjectToCharSequence("Error"));
 if (true) break;

case 22:
//C
this.state = 25;
;
 if (true) break;

case 24:
//C
this.state = 25;
this.catchState = 0;
 //BA.debugLineNum = 280;BA.debugLine="Log(LastException)";
parent.__c.LogImpl("72228276",BA.ObjectToString(parent.__c.LastException(ba)),0);
 if (true) break;
if (true) break;

case 25:
//C
this.state = 26;
this.catchState = 0;
;
 if (true) break;

case 26:
//C
this.state = -1;
;
 //BA.debugLineNum = 288;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _querydata() throws Exception{
ResumableSub_QueryData rsub = new ResumableSub_QueryData(this);
rsub.resume(ba, null);
}
public static class ResumableSub_QueryData extends BA.ResumableSub {
public ResumableSub_QueryData(b4a.example.memberpage parent) {
this.parent = parent;
}
b4a.example.memberpage parent;
String[] _parametros = null;
anywheresoftware.b4a.objects.collections.Map _answer = null;
b4a.example.main._dbresult _rs = null;
anywheresoftware.b4a.objects.collections.Map _mapdata = null;
Object[] _row = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
anywheresoftware.b4a.BA.IterableList group11;
int index11;
int groupLen11;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 128;BA.debugLine="Log(\"查詢....\")";
parent.__c.LogImpl("72097153","查詢....",0);
 //BA.debugLineNum = 129;BA.debugLine="clvData.Clear";
parent._clvdata._clear();
 //BA.debugLineNum = 132;BA.debugLine="Try";
if (true) break;

case 1:
//try
this.state = 16;
this.catchState = 15;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 4;
this.catchState = 15;
 //BA.debugLineNum = 133;BA.debugLine="Function01.ProgressShow(Null,\"Connecting to serv";
parent._function01._progressshow /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null),"Connecting to server...");
 //BA.debugLineNum = 134;BA.debugLine="Dim Parametros() As String =  Array As String()";
_parametros = new String[]{};
 //BA.debugLineNum = 135;BA.debugLine="Wait For(B4XPages.MainPage.jRDC.GetRecord(\"membe";
parent.__c.WaitFor("complete", ba, this, parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._jrdc /*b4a.example.jrdc2*/ ._getrecord /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("member_SelectAll",_parametros));
this.state = 17;
return;
case 17:
//C
this.state = 4;
_answer = (anywheresoftware.b4a.objects.collections.Map) result[0];
;
 //BA.debugLineNum = 137;BA.debugLine="If Answer.Get(\"Success\") Then";
if (true) break;

case 4:
//if
this.state = 13;
if (BA.ObjectToBoolean(_answer.Get((Object)("Success")))) { 
this.state = 6;
}else {
this.state = 12;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 138;BA.debugLine="Dim rs As DBResult";
_rs = new b4a.example.main._dbresult();
 //BA.debugLineNum = 139;BA.debugLine="Dim mapData As Map";
_mapdata = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 140;BA.debugLine="rs = Answer.Get(\"Data\")";
_rs = (b4a.example.main._dbresult)(_answer.Get((Object)("Data")));
 //BA.debugLineNum = 141;BA.debugLine="For Each row() As Object In rs.Rows";
if (true) break;

case 7:
//for
this.state = 10;
group11 = _rs.Rows /*anywheresoftware.b4a.objects.collections.List*/ ;
index11 = 0;
groupLen11 = group11.getSize();
this.state = 18;
if (true) break;

case 18:
//C
this.state = 10;
if (index11 < groupLen11) {
this.state = 9;
_row = (Object[])(group11.Get(index11));}
if (true) break;

case 19:
//C
this.state = 18;
index11++;
if (true) break;

case 9:
//C
this.state = 19;
 //BA.debugLineNum = 143;BA.debugLine="mapData.Initialize";
_mapdata.Initialize();
 //BA.debugLineNum = 145;BA.debugLine="mapData.Put(\"mem_no\",row(rs.Columns.Get(\"mem_n";
_mapdata.Put((Object)("mem_no"),_row[(int)(BA.ObjectToNumber(_rs.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("mem_no"))))]);
 //BA.debugLineNum = 146;BA.debugLine="mapData.Put(\"mem_name\",row(rs.Columns.Get(\"mem";
_mapdata.Put((Object)("mem_name"),_row[(int)(BA.ObjectToNumber(_rs.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("mem_name"))))]);
 //BA.debugLineNum = 147;BA.debugLine="mapData.Put(\"mem_password\",row(rs.Columns.Get(";
_mapdata.Put((Object)("mem_password"),_row[(int)(BA.ObjectToNumber(_rs.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("mem_password"))))]);
 //BA.debugLineNum = 148;BA.debugLine="mapData.Put(\"mem_memo\",row(rs.Columns.Get(\"mem";
_mapdata.Put((Object)("mem_memo"),_row[(int)(BA.ObjectToNumber(_rs.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("mem_memo"))))]);
 //BA.debugLineNum = 165;BA.debugLine="Dim p As B4XView = CreateCard(mapData)";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._createcard(_mapdata);
 //BA.debugLineNum = 166;BA.debugLine="clvData.Add(p, mapData)";
parent._clvdata._add(_p,(Object)(_mapdata.getObject()));
 //BA.debugLineNum = 167;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,"查詢完畢!!");
 if (true) break;
if (true) break;

case 10:
//C
this.state = 13;
;
 //BA.debugLineNum = 170;BA.debugLine="Function01.ProgressHide(Null)";
parent._function01._progresshide /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null));
 if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 172;BA.debugLine="Function01.ProgressHide(Null)";
parent._function01._progresshide /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null));
 //BA.debugLineNum = 173;BA.debugLine="xui.MsgboxAsync(\"Problem connecting: \" & Answer";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence("Problem connecting: "+BA.ObjectToString(_answer.Get((Object)("Error")))),BA.ObjectToCharSequence("Error"));
 if (true) break;

case 13:
//C
this.state = 16;
;
 if (true) break;

case 15:
//C
this.state = 16;
this.catchState = 0;
 //BA.debugLineNum = 178;BA.debugLine="Log(LastException)";
parent.__c.LogImpl("72097203",BA.ObjectToString(parent.__c.LastException(ba)),0);
 if (true) break;
if (true) break;

case 16:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 183;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
