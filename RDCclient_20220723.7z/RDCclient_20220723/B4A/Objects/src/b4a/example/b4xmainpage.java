package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.b4xmainpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.homepage _vhomepage = null;
public b4a.example.memberpage _vmemberpage = null;
public b4a.example.jrdc2 _jrdc = null;
public b4a.example.bctoast _toast = null;
public String _pluschar = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _btnlogin = null;
public b4a.example.b4xfloattextfield _txtno = null;
public b4a.example.b4xfloattextfield _txtpassword = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.function01 _function01 = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.httputils2service _httputils2service = null;
public b4a.example.xuiviewsutils _xuiviewsutils = null;
public String  _b4xpage_appear() throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Sub B4XPage_Appear";
 //BA.debugLineNum = 60;BA.debugLine="txtNo.Text = \"1\"";
_txtno._settext /*String*/ ("1");
 //BA.debugLineNum = 61;BA.debugLine="txtPassword.Text = \"1\"";
_txtpassword._settext /*String*/ ("1");
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 43;BA.debugLine="toast.Initialize(Root1)";
_toast._initialize /*String*/ (ba,_root1);
 //BA.debugLineNum = 45;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 46;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 48;BA.debugLine="B4XPages.SetTitle(Me, \"Login\")";
_b4xpages._settitle /*String*/ (ba,this,(Object)("Login"));
 //BA.debugLineNum = 50;BA.debugLine="vHomePage.Initialize";
_vhomepage._initialize /*Object*/ (ba);
 //BA.debugLineNum = 51;BA.debugLine="B4XPages.AddPage(\"HomePage\", vHomePage)";
_b4xpages._addpage /*String*/ (ba,"HomePage",(Object)(_vhomepage));
 //BA.debugLineNum = 52;BA.debugLine="vMemberPage.Initialize";
_vmemberpage._initialize /*Object*/ (ba);
 //BA.debugLineNum = 53;BA.debugLine="B4XPages.AddPage(\"MemberPage\", vMemberPage)";
_b4xpages._addpage /*String*/ (ba,"MemberPage",(Object)(_vmemberpage));
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public void  _btnlogin_click() throws Exception{
ResumableSub_btnLogin_Click rsub = new ResumableSub_btnLogin_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnLogin_Click extends BA.ResumableSub {
public ResumableSub_btnLogin_Click(b4a.example.b4xmainpage parent) {
this.parent = parent;
}
b4a.example.b4xmainpage parent;
String[] _parametros = null;
anywheresoftware.b4a.objects.collections.Map _answer = null;
anywheresoftware.b4a.objects.collections.List _l = null;
b4a.example.main._dbresult _rs = null;
anywheresoftware.b4a.objects.collections.List _userdata = null;
Object[] _row = null;
anywheresoftware.b4a.BA.IterableList group15;
int index15;
int groupLen15;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 83;BA.debugLine="Try";
if (true) break;

case 1:
//try
this.state = 22;
this.catchState = 21;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 4;
this.catchState = 21;
 //BA.debugLineNum = 85;BA.debugLine="Log(\"查詢資料==>\")";
parent.__c.LogImpl("7983044","查詢資料==>",0);
 //BA.debugLineNum = 86;BA.debugLine="Function01.ProgressShow(Null,\"Connecting to serv";
parent._function01._progressshow /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null),"Connecting to server...");
 //BA.debugLineNum = 87;BA.debugLine="Dim Parametros() As String = Array As String(txt";
_parametros = new String[]{parent._txtno._gettext /*String*/ ().trim(),parent._txtpassword._gettext /*String*/ ().trim()};
 //BA.debugLineNum = 88;BA.debugLine="Wait For(jRDC.GetRecord(\"Login\", Parametros)) Co";
parent.__c.WaitFor("complete", ba, this, parent._jrdc._getrecord /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ("Login",_parametros));
this.state = 23;
return;
case 23:
//C
this.state = 4;
_answer = (anywheresoftware.b4a.objects.collections.Map) result[0];
;
 //BA.debugLineNum = 89;BA.debugLine="Function01.ProgressHide(Null)";
parent._function01._progresshide /*String*/ (ba,(b4a.example.b4xloadingindicator)(parent.__c.Null));
 //BA.debugLineNum = 90;BA.debugLine="If Answer.Get(\"Success\") Then";
if (true) break;

case 4:
//if
this.state = 19;
if (BA.ObjectToBoolean(_answer.Get((Object)("Success")))) { 
this.state = 6;
}else {
this.state = 18;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 91;BA.debugLine="Dim l As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 92;BA.debugLine="Dim rs As DBResult";
_rs = new b4a.example.main._dbresult();
 //BA.debugLineNum = 93;BA.debugLine="rs = Answer.Get(\"Data\")";
_rs = (b4a.example.main._dbresult)(_answer.Get((Object)("Data")));
 //BA.debugLineNum = 94;BA.debugLine="l = rs.Rows";
_l = _rs.Rows /*anywheresoftware.b4a.objects.collections.List*/ ;
 //BA.debugLineNum = 95;BA.debugLine="If l.Size > 0 Then 'We get a result";
if (true) break;

case 7:
//if
this.state = 16;
if (_l.getSize()>0) { 
this.state = 9;
}else {
this.state = 15;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 96;BA.debugLine="Dim UserData As List";
_userdata = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 97;BA.debugLine="UserData.Initialize";
_userdata.Initialize();
 //BA.debugLineNum = 99;BA.debugLine="For Each row() As Object In l";
if (true) break;

case 10:
//for
this.state = 13;
group15 = _l;
index15 = 0;
groupLen15 = group15.getSize();
this.state = 24;
if (true) break;

case 24:
//C
this.state = 13;
if (index15 < groupLen15) {
this.state = 12;
_row = (Object[])(group15.Get(index15));}
if (true) break;

case 25:
//C
this.state = 24;
index15++;
if (true) break;

case 12:
//C
this.state = 25;
 //BA.debugLineNum = 100;BA.debugLine="UserData = row";
_userdata = anywheresoftware.b4a.keywords.Common.ArrayToList(_row);
 if (true) break;
if (true) break;

case 13:
//C
this.state = 16;
;
 //BA.debugLineNum = 106;BA.debugLine="B4XPages.ShowPageAndRemovePreviousPages(\"HomeP";
parent._b4xpages._showpageandremovepreviouspages /*String*/ (ba,"HomePage");
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 108;BA.debugLine="xui.MsgboxAsync(\"帳號/密碼錯誤...\", \"Info\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence("帳號/密碼錯誤..."),BA.ObjectToCharSequence("Info"));
 if (true) break;

case 16:
//C
this.state = 19;
;
 if (true) break;

case 18:
//C
this.state = 19;
 //BA.debugLineNum = 112;BA.debugLine="xui.MsgboxAsync(\"Problem connecting: \" & Answer";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence("Problem connecting: "+BA.ObjectToString(_answer.Get((Object)("Error")))),BA.ObjectToCharSequence("Error"));
 if (true) break;

case 19:
//C
this.state = 22;
;
 if (true) break;

case 21:
//C
this.state = 22;
this.catchState = 0;
 //BA.debugLineNum = 118;BA.debugLine="Log(LastException)";
parent.__c.LogImpl("7983077",BA.ObjectToString(parent.__c.LastException(ba)),0);
 if (true) break;
if (true) break;

case 22:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 189;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _complete(anywheresoftware.b4a.objects.collections.Map _answer) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Public vHomePage As HomePage";
_vhomepage = new b4a.example.homepage();
 //BA.debugLineNum = 13;BA.debugLine="Public vMemberPage As MemberPage";
_vmemberpage = new b4a.example.memberpage();
 //BA.debugLineNum = 17;BA.debugLine="Public jRDC As jRDC2";
_jrdc = new b4a.example.jrdc2();
 //BA.debugLineNum = 18;BA.debugLine="Public toast As BCToast";
_toast = new b4a.example.bctoast();
 //BA.debugLineNum = 19;BA.debugLine="Public Const PlusChar As String = Chr(0xF067) '+";
_pluschar = BA.ObjectToString(__c.Chr(((int)0xf067)));
 //BA.debugLineNum = 25;BA.debugLine="Private btnLogin As B4XView";
_btnlogin = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Public txtNo As B4XFloatTextField";
_txtno = new b4a.example.b4xfloattextfield();
 //BA.debugLineNum = 27;BA.debugLine="Public txtPassword As B4XFloatTextField";
_txtpassword = new b4a.example.b4xfloattextfield();
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 35;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 38;BA.debugLine="jRDC.Initialize";
_jrdc._initialize /*String*/ (ba);
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public String  _txtno_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Sub txtNo_TextChanged (Old As String, New As Strin";
 //BA.debugLineNum = 65;BA.debugLine="If New.Length > 0 And txtPassword.text.Length >0";
if (_new.length()>0 && _txtpassword._gettext /*String*/ ().length()>0) { 
 //BA.debugLineNum = 66;BA.debugLine="btnLogin.Enabled = True";
_btnlogin.setEnabled(__c.True);
 }else {
 //BA.debugLineNum = 68;BA.debugLine="btnLogin.Enabled = False";
_btnlogin.setEnabled(__c.False);
 };
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public String  _txtpassword_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 71;BA.debugLine="Sub txtPassword_TextChanged (Old As String, New As";
 //BA.debugLineNum = 72;BA.debugLine="If New.Length > 0 And txtNo.text.Length >0 Then";
if (_new.length()>0 && _txtno._gettext /*String*/ ().length()>0) { 
 //BA.debugLineNum = 73;BA.debugLine="btnLogin.Enabled = True";
_btnlogin.setEnabled(__c.True);
 }else {
 //BA.debugLineNum = 75;BA.debugLine="btnLogin.Enabled = False";
_btnlogin.setEnabled(__c.False);
 };
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
