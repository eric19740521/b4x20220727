package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class jrdc2 extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.jrdc2");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.jrdc2.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _rdclink = "";
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.function01 _function01 = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.httputils2service _httputils2service = null;
public b4a.example.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 12;BA.debugLine="Private const rdcLink As String = \"https://b234.t";
_rdclink = "https://b234.top/rdc";
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public b4a.example.main._dbcommand  _createcommand(String _name,Object[] _parameters) throws Exception{
b4a.example.main._dbcommand _cmd = null;
 //BA.debugLineNum = 26;BA.debugLine="Private Sub CreateCommand(Name As String, Paramete";
 //BA.debugLineNum = 27;BA.debugLine="Dim cmd As DBCommand";
_cmd = new b4a.example.main._dbcommand();
 //BA.debugLineNum = 28;BA.debugLine="cmd.Initialize";
_cmd.Initialize();
 //BA.debugLineNum = 29;BA.debugLine="cmd.Name = Name";
_cmd.Name /*String*/  = _name;
 //BA.debugLineNum = 30;BA.debugLine="If Parameters <> Null Then cmd.Parameters = Param";
if (_parameters!= null) { 
_cmd.Parameters /*Object[]*/  = _parameters;};
 //BA.debugLineNum = 31;BA.debugLine="Return cmd";
if (true) return _cmd;
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return null;
}
public b4a.example.dbrequestmanager  _createrequest() throws Exception{
b4a.example.dbrequestmanager _req = null;
 //BA.debugLineNum = 20;BA.debugLine="Private Sub CreateRequest As DBRequestManager";
 //BA.debugLineNum = 21;BA.debugLine="Dim req As DBRequestManager";
_req = new b4a.example.dbrequestmanager();
 //BA.debugLineNum = 22;BA.debugLine="req.Initialize(Me, rdcLink)";
_req._initialize /*String*/ (ba,this,_rdclink);
 //BA.debugLineNum = 23;BA.debugLine="Return req";
if (true) return _req;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _getrecord(String _command,String[] _parameters) throws Exception{
ResumableSub_GetRecord rsub = new ResumableSub_GetRecord(this,_command,_parameters);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_GetRecord extends BA.ResumableSub {
public ResumableSub_GetRecord(b4a.example.jrdc2 parent,String _command,String[] _parameters) {
this.parent = parent;
this._command = _command;
this._parameters = _parameters;
}
b4a.example.jrdc2 parent;
String _command;
String[] _parameters;
anywheresoftware.b4a.objects.collections.Map _answer = null;
b4a.example.dbrequestmanager _req = null;
b4a.example.main._dbcommand _cmd = null;
b4a.example.httpjob _j = null;
b4a.example.main._dbresult _res = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 35;BA.debugLine="Dim Answer As Map";
_answer = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 36;BA.debugLine="Answer.Initialize";
_answer.Initialize();
 //BA.debugLineNum = 37;BA.debugLine="Dim req As DBRequestManager = CreateRequest";
_req = parent._createrequest();
 //BA.debugLineNum = 38;BA.debugLine="Dim cmd As DBCommand = CreateCommand(Command, par";
_cmd = parent._createcommand(_command,(Object[])(_parameters));
 //BA.debugLineNum = 39;BA.debugLine="Wait For (req.ExecuteQuery(cmd, 0, Null)) JobDone";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_req._executequery /*b4a.example.httpjob*/ (_cmd,(int) (0),parent.__c.Null)));
this.state = 7;
return;
case 7:
//C
this.state = 1;
_j = (b4a.example.httpjob) result[0];
;
 //BA.debugLineNum = 40;BA.debugLine="Answer.Put(\"Success\", j.Success)";
_answer.Put((Object)("Success"),(Object)(_j._success /*boolean*/ ));
 //BA.debugLineNum = 41;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 42;BA.debugLine="req.HandleJobAsync(j, \"req\")";
_req._handlejobasync /*void*/ (_j,"req");
 //BA.debugLineNum = 43;BA.debugLine="Wait For (req) req_Result(Res As DBResult)";
parent.__c.WaitFor("req_result", ba, this, (Object)(_req));
this.state = 8;
return;
case 8:
//C
this.state = 6;
_res = (b4a.example.main._dbresult) result[0];
;
 //BA.debugLineNum = 45;BA.debugLine="req.PrintTable(Res)";
_req._printtable /*String*/ (_res);
 //BA.debugLineNum = 46;BA.debugLine="Answer.Put(\"Message\",\"Data have been read succes";
_answer.Put((Object)("Message"),(Object)("Data have been read successfully"));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 48;BA.debugLine="Log(\"ERROR: \" & j.ErrorMessage)";
parent.__c.LogImpl("73538958","ERROR: "+_j._errormessage /*String*/ ,0);
 //BA.debugLineNum = 49;BA.debugLine="Answer.Put(\"Error\", j.ErrorMessage)";
_answer.Put((Object)("Error"),(Object)(_j._errormessage /*String*/ ));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 51;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 52;BA.debugLine="Answer.Put(\"Data\",Res)";
_answer.Put((Object)("Data"),(Object)(_res));
 //BA.debugLineNum = 54;BA.debugLine="Return Answer";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_answer));return;};
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _jobdone(b4a.example.httpjob _j) throws Exception{
}
public void  _req_result(b4a.example.main._dbresult _res) throws Exception{
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 16;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _insertupdaterecord(String _command,String[] _parameters) throws Exception{
ResumableSub_InsertUpdateRecord rsub = new ResumableSub_InsertUpdateRecord(this,_command,_parameters);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_InsertUpdateRecord extends BA.ResumableSub {
public ResumableSub_InsertUpdateRecord(b4a.example.jrdc2 parent,String _command,String[] _parameters) {
this.parent = parent;
this._command = _command;
this._parameters = _parameters;
}
b4a.example.jrdc2 parent;
String _command;
String[] _parameters;
anywheresoftware.b4a.objects.collections.Map _answer = null;
b4a.example.main._dbcommand _cmd = null;
b4a.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 58;BA.debugLine="Dim Answer As Map";
_answer = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 59;BA.debugLine="Answer.Initialize";
_answer.Initialize();
 //BA.debugLineNum = 60;BA.debugLine="Dim cmd As DBCommand = CreateCommand(Command, par";
_cmd = parent._createcommand(_command,(Object[])(_parameters));
 //BA.debugLineNum = 61;BA.debugLine="Dim j As HttpJob = CreateRequest.ExecuteBatch(Arr";
_j = parent._createrequest()._executebatch /*b4a.example.httpjob*/ (anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)(_cmd)}),parent.__c.Null);
 //BA.debugLineNum = 62;BA.debugLine="Wait For(j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (b4a.example.httpjob) result[0];
;
 //BA.debugLineNum = 63;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 64;BA.debugLine="Log(\"successfully!\")";
parent.__c.LogImpl("73604487","successfully!",0);
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 66;BA.debugLine="Answer.Put(\"Success\",j.Success)";
_answer.Put((Object)("Success"),(Object)(_j._success /*boolean*/ ));
 //BA.debugLineNum = 67;BA.debugLine="Answer.Put(\"Error\", j.ErrorMessage)";
_answer.Put((Object)("Error"),(Object)(_j._errormessage /*String*/ ));
 //BA.debugLineNum = 68;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 69;BA.debugLine="Return Answer";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_answer));return;};
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
